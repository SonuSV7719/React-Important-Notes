import React from "react";
import context from "./context";

const ContextProvider = ({ children }) => {
  const data = { username: "Sonu", password: "sonu" };

  return <context.Provider value={data}>{children}</context.Provider>;
};

export default ContextProvider;
