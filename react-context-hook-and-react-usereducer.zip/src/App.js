import "./styles.css";
import ContextProvider from "./context/ContextProvider";
import { useContext, useReducer } from "react";
import context from "./context/context";

const ACTION = {
  INCREMENT: "increment",
  DECREMENT: "decrement",
};

const reducer = (state, action) => {
  switch (action.type) {
    case ACTION.INCREMENT:
      return { count: state.count + 1 };
    case ACTION.DECREMENT:
      return { count: state.count - 1 };
    default:
      return state;
  }
};

export default function App() {
  const initialState = { count: 0 };
  const { username, password } = useContext(context);

  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <div className="App">
      <h1>
        Hello CodeSandbox: {username} {password}
      </h1>
      <p>{state.count}</p>
      <button onClick={() => dispatch({ type: ACTION.INCREMENT })}>
        Increment
      </button>
      <button onClick={() => dispatch({ type: ACTION.DECREMENT })}>
        Decrement
      </button>
      <h2>Start editing to see some magic happen!</h2>
    </div>
  );
}
