export const INCREMENT = "increment";
export const DECREMENT = "decrement";

export const increment = () => {
  return {
    type: INCREMENT,
  };
};

export const decrement = () => {
  return {
    type: DECREMENT,
  };
};
