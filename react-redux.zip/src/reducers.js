import { INCREMENT, DECREMENT } from "./actions";

const initialState = {
  count: 0,
};

const rootReducer = (state = initialState, action) => {
  //   console.log(state);
  switch (action.type) {
    case INCREMENT:
      console.log({ ...state, count: state.count + 1 });
      return { ...state, count: state.count + 1 };
    case DECREMENT:
      return { ...state, count: state.count - 1 };
    default:
      return state;
  }
};

export default rootReducer;
